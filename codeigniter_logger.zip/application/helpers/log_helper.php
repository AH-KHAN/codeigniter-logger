<?php
if (!function_exists('save_log')) {

    function save_log($user_id=0,$status="",$data="",$url="") {
		$year=date("Y");
		$month = strtolower(date("m"));
		$file = date("d").".log";
		$path="logs/".$year."/".$month;
		$fpath = $path."/".$file;
		$time = date("Y/d/m h:m:s");
		$contents = "User_ID:$user_id\r\nIP:".$_SERVER['REMOTE_ADDR']."\r\nData:$data\r\nStatus:$status\r\nPath:$url\r\nTime:$time\r\n###############\r\n";
		if (!file_exists($path)) {
			mkdir($path, 0777, true);
		}
		file_put_contents($fpath, $contents, FILE_APPEND);
	}
}
?>