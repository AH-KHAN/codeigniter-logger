<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logs extends CI_Controller {

	
	public function index()
	{
		
		$this->load->helper("log");
		$this->load->helper("url");
		echo save_log("0","200","{'asdf':done}",base_url(uri_string()));
	}
}
